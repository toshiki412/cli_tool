/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package cmd

import (
	"github.com/spf13/cobra"
)

// applyCmd represents the apply command
var applyCmd = &cobra.Command{
	Use:   "apply",
	Short: "A brief description of your command",
	Long: `A longer description that spans multiple lines and likely contains examples
and usage of using your command. For example:

Cobra is a CLI library for Go that empowers applications.
This application is a tool to generate the needed files
to quickly create a Cobra application.`,
	Run: func(cmd *cobra.Command, args []string) {
		// tmpDir, err := file.MakeTempDir()
		// cobra.CheckErr(err)
		// defer os.RemoveAll(tmpDir)

		// // 展開する
		// compress.Decompress(tmpDir, tmpFile)

		// // 展開したものを適用する
		// for _, target := range setting.Targets {
		// 	cfg.DispatchTarget(target, cfg.TargetFuncTable{
		// 		Mysql: func(conf cfg.TargetMysqlType) {
		// 			dump_mysql.Import(tmpDir, conf)
		// 		},
		// 		File: func(conf cfg.TargetFileType) {
		// 			dump_file.Expand(tmpDir, conf)
		// 		},
		// 	})
		// }

	},
}

func init() {
	rootCmd.AddCommand(applyCmd)
}
